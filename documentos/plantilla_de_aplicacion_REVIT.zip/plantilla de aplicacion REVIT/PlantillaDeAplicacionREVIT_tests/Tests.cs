﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PlantillaDeAplicacionREVIT
{
    [TestClass]
    public class Tests
    {

        [TestMethod]
        public void DummyTest()
        {
            Assert.IsTrue(true);
        }


    }
}
