﻿using System;

namespace PlantillaDeAplicacionREVIT
{
    public class Prueba
    {
        public String canta()
        {
            return "Hola, mundo.";
        }
    }
}
